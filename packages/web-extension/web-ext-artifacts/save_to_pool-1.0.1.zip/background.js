let browser_ = null;
if (typeof browser !== 'undefined') {
  browser_ = browser;
  browserSupportsPromises_ = true;
} else if (typeof chrome !== 'undefined') {
  browser_ = chrome;
  browserSupportsPromises_ = false;
}

// TODO: bookmarks sync
// https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/bookmarks
// https://github.com/mdn/webextensions-examples/blob/master/bookmark-it/background.js

function getCurrentTabUrl(cb) {
  const queryInfo = {
    active: true,
    currentWindow: true
  };

  browser_.tabs.query(queryInfo, function(tabs) {
    const tab = tabs[0];
    const url = tab.url;
    cb(url);
  });
}

function saveToPool({ linkUrl, selectionText, menuItemId }, tab) {
  if (menuItemId === 'open-pool') {
    return openPool();
  }

  if (linkUrl) {
    browser_.tabs.create({
      url: `https://pool.social/share?url=${encodeURIComponent(
        linkUrl
      )}&title=${encodeURIComponent(selectionText)}`
    });
  } else {
    getCurrentTabUrl(url => {
      browser_.tabs.create({
        url: `https://pool.social/share?url=${encodeURIComponent(
          linkUrl
        )}&title=${encodeURIComponent(selectionText)}`
      });
    });
  }
}

function openPool() {
  browser_.tabs.create({
    url: 'https://pool.social'
  });
}

browser_.runtime.onInstalled.addListener(() => {
  browser_.contextMenus.create({
    id: 'pool',
    title: 'Save to Pool',
    contexts: ['selection', 'page', 'link']
  });

  browser_.contextMenus.create({
    id: 'open-pool',
    title: 'Open Pool',
    contexts: ['all']
  });

  // TODO: Save all tabs on Pool

  browser_.contextMenus.onClicked.addListener(saveToPool);
});

/*
chrome.runtime.onInstalled.addListener(function() {
  chrome.contextMenus.create({ id: "options", title: "Options", contexts: ["launcher"] })
})

chrome.contextMenus.onClicked.addListener(function(info) {
  if(info.menuItemId == "options") {
    chrome.app.window.create("options.html")
  }
})
*/
