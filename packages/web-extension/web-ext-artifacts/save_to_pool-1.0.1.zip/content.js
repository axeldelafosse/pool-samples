/*
  window.addEventListener('message', function(event) {
    // TODO: window.close() when link is posted
  });
*/
